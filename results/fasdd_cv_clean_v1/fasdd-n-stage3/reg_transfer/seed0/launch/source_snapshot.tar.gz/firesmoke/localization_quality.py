"""Experimental classwise localization-quality readout, not installed in a head.

The prototype consumes DFL statistics, the existing 64-channel regression tower
feature, detached class probabilities and stride identity. It adds 1,802 params.
Training/inference integration is a subsequent registered experiment.
"""
from __future__ import annotations

import math

import torch
from torch import nn
import torch.nn.functional as F


class LocalizationQualityReadout(nn.Module):
    def __init__(self):
        super().__init__()
        with torch.random.fork_rng(devices=[]):
            self.reg_reduce = nn.Conv1d(64, 8, 1)
            self.predictor = nn.Sequential(nn.Conv1d(37, 32, 1), nn.SiLU(), nn.Conv1d(32, 2, 1))

    @staticmethod
    def distribution_statistics(box_logits):
        if box_logits.ndim != 3 or box_logits.shape[1] != 64:
            raise ValueError("Expected Bx64xA DFL logits (four sides, 16 bins)")
        probability = box_logits.float().reshape(box_logits.shape[0], 4, 16, -1).softmax(2)
        top4 = probability.topk(4, dim=2).values
        support = torch.arange(16, device=probability.device).view(1, 1, 16, 1)
        mean = (probability * support).sum(2, keepdim=True) / 15
        entropy = -(probability * probability.clamp_min(1e-12).log()).sum(2, keepdim=True) / math.log(16)
        return torch.cat((top4, mean, entropy), dim=2).flatten(1, 2)

    def forward(self, box_logits, regression_features, class_logits, level_ids, *, detach_inputs=True):
        b, _, a = box_logits.shape
        if regression_features.shape != (b, 64, a) or class_logits.shape != (b, 2, a):
            raise ValueError("All predictor inputs must use the same anchor order")
        if level_ids.shape != (a,) or level_ids.dtype != torch.long:
            raise ValueError("level_ids must be a long vector with one entry per anchor")
        if bool(((level_ids < 0) | (level_ids > 2)).any()):
            raise ValueError("Only stride8/16/32 levels are registered")
        if detach_inputs:
            box_logits = box_logits.detach()
            regression_features = regression_features.detach()
            class_logits = class_logits.detach()
        stats = self.distribution_statistics(box_logits).to(regression_features.dtype)
        reg = F.silu(self.reg_reduce(regression_features))
        level = F.one_hot(level_ids, 3).T.unsqueeze(0).expand(b, -1, -1).to(reg.dtype)
        x = torch.cat((stats, reg, class_logits.sigmoid(), level), dim=1)
        return self.predictor(x)

    @staticmethod
    def score(class_logits, quality_logits, exponent=1.0):
        if class_logits.shape != quality_logits.shape or not 0 <= exponent <= 1:
            raise ValueError("Score shapes must agree; exponent must be in [0,1]")
        return class_logits.sigmoid() * quality_logits.sigmoid().pow(exponent)
